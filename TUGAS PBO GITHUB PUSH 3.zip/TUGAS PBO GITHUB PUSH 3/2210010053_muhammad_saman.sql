-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 13, 2024 at 03:06 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `2210010053_muhammad_saman`
--

-- --------------------------------------------------------

--
-- Table structure for table `belajar`
--

CREATE TABLE `belajar` (
  `npm` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `telpon` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `komoditas`
--

CREATE TABLE `komoditas` (
  `Nama` varchar(70) NOT NULL,
  `Lokasi` varchar(70) NOT NULL,
  `Subsektor` varchar(70) NOT NULL,
  `Luas_tanam` varchar(20) NOT NULL,
  `Luas_panen` varchar(20) NOT NULL,
  `Produktivitas` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `komoditas`
--

INSERT INTO `komoditas` (`Nama`, `Lokasi`, `Subsektor`, `Luas_tanam`, `Luas_panen`, `Produktivitas`) VALUES
('cabai', 'Nagara', 'Perkebunan', '504MeterPersegi', '293MeterPersegi', '70Kg');

-- --------------------------------------------------------

--
-- Table structure for table `lokasi`
--

CREATE TABLE `lokasi` (
  `Provinsi` varchar(70) NOT NULL,
  `Kabupaten` varchar(70) NOT NULL,
  `Kecamatan` varchar(70) NOT NULL,
  `Desa` varchar(70) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lokasi`
--

INSERT INTO `lokasi` (`Provinsi`, `Kabupaten`, `Kecamatan`, `Desa`) VALUES
('ddd', 'add', 'Kupang', 'Apam');

-- --------------------------------------------------------

--
-- Table structure for table `penyuluh`
--

CREATE TABLE `penyuluh` (
  `Nama` varchar(70) NOT NULL,
  `Alamat` varchar(70) NOT NULL,
  `Status` varchar(70) NOT NULL,
  `Wilayah` varchar(70) NOT NULL,
  `Subsektor` varchar(70) NOT NULL,
  `Tgl_mulai` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penyuluh`
--

INSERT INTO `penyuluh` (`Nama`, `Alamat`, `Status`, `Wilayah`, `Subsektor`, `Tgl_mulai`) VALUES
('Jl. Banjar Raya', 'Aktif', 'Banjarnegara', 'Perkebunan', '3 Mei 2021', 'Ujang');

-- --------------------------------------------------------

--
-- Table structure for table `petani`
--

CREATE TABLE `petani` (
  `Nama` varchar(70) NOT NULL,
  `Alamat` varchar(70) NOT NULL,
  `Poktan` varchar(70) NOT NULL,
  `Komoditas` varchar(70) NOT NULL,
  `Pelatihan` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `petani`
--

INSERT INTO `petani` (`Nama`, `Alamat`, `Poktan`, `Komoditas`, `Pelatihan`) VALUES
('Saman', 'Jl. Banua Anyar', 'Baru Jaya', 'Beras', 'Pertanian Modern');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `belajar`
--
ALTER TABLE `belajar`
  ADD PRIMARY KEY (`npm`);

--
-- Indexes for table `komoditas`
--
ALTER TABLE `komoditas`
  ADD PRIMARY KEY (`Nama`);

--
-- Indexes for table `lokasi`
--
ALTER TABLE `lokasi`
  ADD PRIMARY KEY (`Provinsi`);

--
-- Indexes for table `penyuluh`
--
ALTER TABLE `penyuluh`
  ADD PRIMARY KEY (`Nama`);

--
-- Indexes for table `petani`
--
ALTER TABLE `petani`
  ADD PRIMARY KEY (`Nama`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
