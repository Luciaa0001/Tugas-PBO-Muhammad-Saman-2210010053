/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PERTANIAN_VAR;

public class Penyuluh {
    private String nama;

    public Penyuluh(String nama) {
        this.nama = nama;
    }

    public void memberiPetunjuk() {
        System.out.println("Penyuluh " + nama + " memberikan petunjuk kepada petani.");
    }
}
